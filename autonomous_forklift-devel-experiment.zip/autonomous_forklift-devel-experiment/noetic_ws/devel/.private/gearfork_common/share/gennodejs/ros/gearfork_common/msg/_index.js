
"use strict";

let forklift_diagnostics_msg = require('./forklift_diagnostics_msg.js');

module.exports = {
  forklift_diagnostics_msg: forklift_diagnostics_msg,
};
